DROP TABLE IF EXISTS `{project_id_stgmsrl}.stg_modelo_prospeccion.cotizacion_journey_tmp`;
DROP TABLE IF EXISTS `{project_id_stgmsrl}.stg_modelo_prospeccion.cotizacion_cotweb_tmp`;
DROP TABLE IF EXISTS `{project_id_stgmsrl}.stg_modelo_prospeccion.cotizacion_sas_tmp`;
DROP TABLE IF EXISTS `{project_id_stgmsrl}.stg_modelo_prospeccion.cotizacion_finrisk_tmp`;
DROP TABLE IF EXISTS `{project_id_stgmsrl}.stg_modelo_prospeccion.cotizacion_union_tmp`;